package core.framework.impl.module;

import core.framework.api.async.Executor;
import core.framework.api.http.HTTPMethod;
import core.framework.api.util.Lists;
import core.framework.api.util.Properties;
import core.framework.api.web.Controller;
import core.framework.api.web.WebContext;
import core.framework.api.web.site.WebDirectory;
import core.framework.impl.async.ExecutorImpl;
import core.framework.impl.inject.BeanFactory;
import core.framework.impl.inject.ShutdownHook;
import core.framework.impl.log.DefaultLoggerFactory;
import core.framework.impl.log.LogManager;
import core.framework.impl.log.stat.Metrics;
import core.framework.impl.web.ControllerActionBuilder;
import core.framework.impl.web.ControllerClassValidator;
import core.framework.impl.web.ControllerHolder;
import core.framework.impl.web.ControllerInspector;
import core.framework.impl.web.HTTPServer;
import core.framework.impl.web.management.HealthCheckController;
import core.framework.impl.web.management.MemoryUsageController;
import core.framework.impl.web.management.PropertyController;
import core.framework.impl.web.management.ThreadInfoController;
import core.framework.impl.web.route.PathPatternValidator;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author neo
 */
public final class ModuleContext {
    public final BeanFactory beanFactory;
    public final List<Runnable> startupHook = Lists.newArrayList();
    public final ShutdownHook shutdownHook = new ShutdownHook();
    public final Properties properties = new Properties();
    public final HTTPServer httpServer;
    public final LogManager logManager;
    public final MockFactory mockFactory;
    public final List<Metrics> metrics = Lists.newArrayList();
    public final ConfigState config = new ConfigState();
    private BackgroundTaskExecutor backgroundTask;

    public ModuleContext(BeanFactory beanFactory, MockFactory mockFactory) {
        this.beanFactory = beanFactory;
        this.mockFactory = mockFactory;

        this.logManager = ((DefaultLoggerFactory) LoggerFactory.getILoggerFactory()).logManager;
        if (!isTest()) {
            startupHook.add(logManager::start);
            shutdownHook.add(logManager::stop);
        }

        httpServer = new HTTPServer(logManager);
        beanFactory.bind(WebContext.class, null, httpServer.handler.webContext);
        beanFactory.bind(WebDirectory.class, null, httpServer.siteManager.webDirectory);
        if (!isTest()) {
            startupHook.add(httpServer::start);
            shutdownHook.add(httpServer::stop);
        }

        Executor executor;
        if (!isTest()) {
            executor = new ExecutorImpl(logManager);
            shutdownHook.add(((ExecutorImpl) executor)::stop);
        } else {
            executor = mockFactory.create(Executor.class);
        }
        beanFactory.bind(Executor.class, null, executor);

        if (!isTest()) {
            route(HTTPMethod.GET, "/health-check", new HealthCheckController(), true);
            route(HTTPMethod.GET, "/_sys/memory", new MemoryUsageController(), true);
            ThreadInfoController threadInfoController = new ThreadInfoController();
            route(HTTPMethod.GET, "/_sys/thread", threadInfoController::threadUsage, true);
            route(HTTPMethod.GET, "/_sys/thread-dump", threadInfoController::threadDump, true);
            PropertyController propertyController = new PropertyController(properties);
            route(HTTPMethod.GET, "/_sys/property", propertyController, true);
        }
    }

    public BackgroundTaskExecutor backgroundTask() {
        if (backgroundTask == null) {
            backgroundTask = new BackgroundTaskExecutor();
            if (!isTest()) {
                startupHook.add(backgroundTask::start);
                shutdownHook.add(backgroundTask::stop);
            }
        }
        return backgroundTask;
    }

    public void route(HTTPMethod method, String path, Controller controller, boolean skipInterceptor) {
        new PathPatternValidator(path).validate();
        ControllerInspector inspector = new ControllerInspector(controller);
        new ControllerClassValidator(inspector.targetClass).validate();
        String action = new ControllerActionBuilder(method, path).build();
        httpServer.handler.route.add(method, path, new ControllerHolder(controller, inspector.targetMethod, inspector.controllerInfo, action, skipInterceptor));
    }

    public boolean isTest() {
        return mockFactory != null;
    }
}
