package core.framework.log;

import core.framework.internal.log.ActionLog;
import core.framework.internal.log.LogManager;
import core.framework.internal.log.Trace;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;

/**
 * @author neo
 */
public final class ActionLogContext {
    private static final Logger LOGGER = LoggerFactory.getLogger(ActionLogContext.class);

    @Nullable
    public static String id() {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog == null) return null;
        return actionLog.id;
    }

    public static List<String> get(String key) {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog == null) return List.of();
        List<String> values = actionLog.context.get(key);
        if (values == null) return List.of();
        return values;
    }

    public static void put(String key, @Nullable Object... values) {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog != null) {    // here to check null is for unit testing the logManager.begin may not be called
            actionLog.context(key, values);
        }
    }

    // to collect numeric metrics, and can be aggregated by Elasticsearch/Kibana
    public static void stat(String key, double value) {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog != null) {
            actionLog.stat(key, value);
        }
    }

    public static void track(String operation, long elapsed) {
        track(operation, elapsed, 0, 0);
    }

    public static void track(String operation, long elapsed, int readEntries, int writeEntries) {
        track(operation, elapsed, readEntries, writeEntries, 0, 0);
    }

    // return the total count of operations within current action
    public static void track(String operation, long elapsed, int readEntries, int writeEntries, long readBytes, long writeBytes) {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog == null) return;    // be called without action context
        actionLog.track(operation, elapsed, readEntries, writeEntries, readBytes, writeBytes);
    }

    public static void triggerTrace(boolean cascade) {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog != null) {
            Trace trace = cascade ? Trace.CASCADE : Trace.CURRENT;
            LOGGER.debug("trigger trace, trace={}", trace);
            actionLog.trace = trace;
        }
    }

    // for non-critical actions, set max process time to avoid slow_process warning
    public static void maxProcessTime(Duration duration) {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog != null) {
            actionLog.warningContext.maxProcessTimeInNano(duration.toNanos());
        }
    }

    // for long process, use this guidance to determine whether continue to do more work
    @Nullable
    public static Duration remainingProcessTime() {
        ActionLog actionLog = LogManager.currentActionLog();
        if (actionLog == null) return null;
        return Duration.ofNanos(actionLog.remainingProcessTimeInNano());
    }
}
